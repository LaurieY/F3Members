<div class="navbar">
<!-- in member nav.htm -->
    <div class="navbar-inner">
        <ul class="nav">

            <li <?php if ($page_head == 'Member List'): ?>class="active"<?php endif; ?>><a href="<?php echo $BASE.'/'; ?>"><em class="icon-th icon-black"></em> View Members</a></li>
      		
			<?php if ($page_role == 'admin'): ?>
			<!-- page role is admin -->
            <li class="active"><a href="<?php echo $BASE.'/admin'; ?>"><em class="icon-plus-sign icon-black"></em> Admin</a></li>
            <?php endif; ?>

           
        </ul>
		<!-- member nav after /ul-->
    </div>
</div>