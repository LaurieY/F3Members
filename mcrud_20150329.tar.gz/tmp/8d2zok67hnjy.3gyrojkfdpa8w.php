<!DOCTYPE html>
<html lang="en">
    <head>
        <base href="<?php echo $BASE.'/'.$UI; ?>" />        
        <title><?php echo $site; ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- Bootstrap -->
		<!-- script src="../../ui/js/jquery-1.11.0.min.js" type="text/javascript"></script -->
		<script src="../../ui/js/jquery-1.11.2.js" type="text/javascript"></script>
        <link href="../../ui/css/bootstrap.min.css" rel="stylesheet" media="screen" >
		<script src="../../ui/js/bootstrap.min.js"></script >
		 

		  <script src= "http://code.jquery.com/ui/1.11.4/jquery-ui.min.js" type="text/javascript"></script>
		  <script src="../../ui/js/trirand/i18n/grid.locale-en.js" type="text/javascript"></script>
		  <!-- script src="../../ui/js/trirand/jquery.jqGrid.min.js" type="text/javascript"></script -->
		  <script src="../../ui/js/trirand/jquery.jqGrid.src.js" type="text/javascript"></script>
		  
		  <link rel="stylesheet" type="text/css" media="screen" href="../../ui/css/trirand/ui.jqgrid.css">
		  <link rel="stylesheet" type="text/css" media="screen" href="../../ui/css/jquery-ui.css">

	        <link href="../../ui/css/crud.css" rel="stylesheet" media="screen">		
    </head>

    <body>
<!-- contents of header.htm -->
        <div class="container">
           <?php if ($page_head == 'Admin'): ?>
		   
		   <?php echo $this->render('admin/nav.htm',$this->mime,get_defined_vars()); ?>
		   
		   <?php else: ?>
		   <?php echo $this->render('member/nav.htm',$this->mime,get_defined_vars()); ?>
		   
		   <?php endif; ?>
            <div class="jumbotron">
                <h1><?php echo $page_head; ?></h1>
            </div>



            <?php if ($message): ?>
            <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <strong><?php echo $message; ?></strong>
            </div>
            <?php endif; ?>

	
