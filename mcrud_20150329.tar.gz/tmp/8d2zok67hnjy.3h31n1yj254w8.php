<?php echo $this->render('header.htm',$this->mime,get_defined_vars()); ?>

<?php echo $this->render($view,$this->mime,get_defined_vars()); ?>
          	 
<?php echo $this->render('footer.htm',$this->mime,get_defined_vars()); ?>
