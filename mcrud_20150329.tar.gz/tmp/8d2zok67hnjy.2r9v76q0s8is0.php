<script type="text/javascript">
$(function () {
    $("#list").jqGrid({ 
        url: "/membergrid",
		editurl:"/editmember",
        datatype: "xml",
        mtype: "GET",
        colNames: ["Surname", "Forename", "Num.", "Phone","Mobile","Email","Type","Location","Paid","Amt Paid","Joined"],//],
        colModel: [
           
			{ name: "surname", width: 120,editable: true, edittype:"text",searchoptions : {
                            // show search options
                            sopt: ["bw","eq"] // ge = greater or equal to, le = less or equal to, eq = equal to  							
						}},
             {name: "forename", width: 120,editable: true, edittype:"text"},
			 { name: "membnum", width: 80,searchoptions : {sopt: ["eq"] } }, //  eq = equal to  	
			{ name: "phone", width: 85, align: "right",editable: true, edittype:"text" },
            { name: "mobile", width: 85, align: "right",editable: true, edittype:"text" }, 
            { name: "email", width: 210, align: "right",editable: true, edittype:"text" ,searchoptions : {sopt: ["cn"] }}, 
			 { name: "membtype", width: 90, align: "right",editable: true, },
             { name: "location", width: 65, align: "right" },
			 { name: "paidthisyear", width: 80, align: "right" ,editable: true, 			  edittype:"text", }, 
			  { name: "amtpaidthisyear", width: 80, align: "right",editable: true,searchoptions : {sopt: ["ge","le"] },searchrules:{integer:true}},
			  { name: "datejoined", width: 100, align: "right",search:false }, /**/
			
        ],
        pager: "#pager",
		onSelectRow: editRow,
        rowNum: 10,
        rowList: [10, 20, 30],
        sortname: "membnum",
        sortorder: "asc",
        viewrecords: true,
        gridview: true,
        autoencode: true,
        caption: "Members auto grid",
		 height:'auto',
		 altRows: true,
		 footerrow : true,
		 userDataOnFooter : true,
	 multiselect: true,
	// multikey: "ctrlKey",
	 
    }); 
            var lastSelection;
function editRow(id) { var grid = $("#list");
                if (id && id !== lastSelection) {
                   
                    grid.jqGrid('restoreRow',lastSelection);
                  //  grid.jqGrid('editRow',id, {keys:true, focusField: 4}); 
				 } grid.jqGrid('editRow',id, true,  '','','','',reload);
                    lastSelection = id;
                
            }
			
			
		function reload(rowid, result) {
		$("#list").trigger("reloadGrid", [{ page: 1}]);
		}
 $('#list').navGrid('#pager',
                { edit: true, add: true, del: true, search: false, refresh: true, view: false, position: "left", cloneToTop: true },
				{
                    closeAfterAdd: true,
                    recreateForm: true,});
			$('#list').jqGrid('filterToolbar',{searchOperators: true,	});
			
	
 var grid = $("#list");

//***************  REFRESH BUTTON **********/
$("#cm1").click( function() { //Refresh
		var grid = $("#list");
		//$('grid').jqGrid('clearGridData');
		//$('grid').jqGrid('setGridParam', {data: dataToLoad});
		//
		  var text = $("#searchText").val();
    var postdata = grid.jqGrid('getGridParam', 'postData');
    // build up the filter
    // ['equal','not equal', 'less', 'less or equal','greater','greater or equal', 'begins with','does not begin with','is in','is not in','ends with','does not end with','contains','does not contain']
    // ['eq','ne','lt','le','gt','ge','bw','bn','in','ni','ew','en','cn','nc']
    var myfilter =  '{"groupOp":"AND","rules":[{"field":"paidthisyear","op":"ne","data":"\'A\'"}]}';         
 

    $.extend(postdata, { filters: myfilter });
    grid.jqGrid('setGridParam', { search: text.length > 0, postData: postdata });        
    grid.trigger("reloadGrid", [{ page: 1}]);$("grid").trigger("reloadGrid", [{ page: 1,datatype:'xml'}]);
 
});
 //***** SHOW only UNPAIDS ***********
	$("#cm2").click( function() { //show only unpaid
   var text = $("#searchText").val();
    var postdata = grid.jqGrid('getGridParam', 'postData');
    // build up the filter
    // ['equal','not equal', 'less', 'less or equal','greater','greater or equal', 'begins with','does not begin with','is in','is not in','ends with','does not end with','contains','does not contain']
    // ['eq','ne','lt','le','gt','ge','bw','bn','in','ni','ew','en','cn','nc']
    var myfilter =  '{"groupOp":"AND","rules":[{"field":"paidthisyear","op":"eq","data":"\'N\'"}]}';         
 

    $.extend(postdata, { filters: myfilter });
    grid.jqGrid('setGridParam', { search: text.length > 0, postData: postdata });        
    grid.trigger("reloadGrid", [{ page: 1}]);
}); 
/***********  Mark Selected Rows as Paid  **/
$("#cm3").click( function() { 
	var s;
	s = $("#list").jqGrid('getGridParam','selarrrow');
	alert(s);
	 
	for(i=0;i <s.length; i++){
		$("#list").jqGrid('resetSelection');
//		$("#list").jqGrid('setCell',s[i],'paidthisyear',"Y");
	//	$("#list").jqGrid('editRow',s[i]);
	rowId=s[i];
	$("#" + rowId).find('td').eq('9').html('Y')
		//$("#list").jqGrid('saveRow',s[i],false,'/editmember');
		$("#list").jqGrid('editRow',s[i]);
		$("#list").jqGrid('saveRow',s[i],false,'/editmember');
	}
	// s is list of id's, try changing it to member  numbers
	//z= $("#list").jqGrid('getCell',s[i],'membnum');
	//alert(z);}
	x= "membnum=2";
	 $.post("\markpaid",        x);

}
);


 // Add Search
$("#mySearch").button().click(function () {
    var text = $("#searchText").val();
    var postdata = grid.jqGrid('getGridParam', 'postData');
    // build up the filter
    // ['equal','not equal', 'less', 'less or equal','greater','greater or equal', 'begins with','does not begin with','is in','is not in','ends with','does not end with','contains','does not contain']
    // ['eq','ne','lt','le','gt','ge','bw','bn','in','ni','ew','en','cn','nc']
    var myfilter =  '{"groupOp":"AND","rules":[{"field":"surname","op":"bw","data":"'.concat(text).concat('"}]}');         
  //  myfilter.rules.push({ field: "surname", op: "cn", data: text });
  //  myfilter.rules.push({ field: "forename", op: "cn", data: text });
 //   myfilter.rules.push({ field: "email", op: "cn", data: text });

    $.extend(postdata, { filters: myfilter });
    grid.jqGrid('setGridParam', { search: text.length > 1, postData: postdata });        
    grid.trigger("reloadGrid", [{ page: 1}]);
});
 
	}			); 
</script>
 

    <table id="list"><tr><td></td></tr></table> 
    <div id="pager"></div> 
	<br>
	<a href="javascript:void(0)" id="cm1">Refresh with NO Filter</a>
	<br>
	<br>
	<a href="javascript:void(0)" id="cm2">Show only Unpaid</a>
		<br>
		<br>
	<a href="javascript:void(0)" id="cm3">Mark Selected as Paid</a>
		<br>
		<br>
		Get Surname starts with
	<fieldset>
<input type="text" name="a" id="searchText" value="Ed"/>
<button type="button" id="mySearch">Search</button>
</fieldset>
