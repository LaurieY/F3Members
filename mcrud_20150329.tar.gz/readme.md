[![Fat-Free Framework](ui/images/logo.png)](http://fatfree.sf.net/)

*A powerful yet easy-to-use PHP micro-framework designed to help you build dynamic and robust Web applications - fast!*

For details visit [http://foysalmamun.wordpress.com/](http://foysalmamun.wordpress.com/2013/03/27/fat-free-crud-with-mvc-tutorial/).