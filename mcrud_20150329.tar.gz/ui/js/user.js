$(document).on('click', function(){
    $( "p" ).append(  "them"  );
});