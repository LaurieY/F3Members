<?php

class MyAjax {
	protected $f3;
	protected $db;

	function beforeroute() {
//$f3->set('message','');
	}

	function afterroute() {
//		echo Template::instance()->render('layout.htm');	
	}

	function __construct() {

        $this->f3=Base::instance();
$f3=$this->f3;
        $db=new DB\SQL(
            $f3->get('db_dns') . $f3->get('db_name'),
            $f3->get('db_user'),
            $f3->get('db_pass')
        );	

		$this->f3=$f3;	
		$this->db=$db;
	}
	public function members() //for POST membergrid
	 {
	 $f3=$this->f3;
	 $members =	new Member($this->db);
	 $f3->set('page_head','User List');
	 $admin_logger = new Log('admin.log');
	$admin_logger->write('in fn members');
	$admin_logger->write('in fn members '.get_class($this->db)." Parent is ".get_parent_class($this->db)."\n");
/**	$class_methods = get_class_methods('DB\SQL');
	foreach ($class_methods as $method_name) {
    $admin_logger->write('in fn members class methods '.$method_name."\n");
	}**/
	
	$admin_logger->write('GET _search = '.$_GET['_search']."\n");
if ($f3->get('GET._search')=='true'){
// set up filters
$filters = $f3->get('GET.filters');
$admin_logger->write('in fn members filters= '.$filters."\n");

$where = "";
        if (isset($filters)) {
            $filters = json_decode($filters);
            $where = " where ";
            $whereArray = array();
            $rules = $filters->rules;
/********************************/
 $groupOperation = $filters->groupOp;
        foreach($rules as $rule) {

            $fieldName = $rule->field;
            $admin_logger->write('in fn members old fieldname = '.$fieldName."\n");
			$admin_logger->write('in fn members old fielddata = '.$rule->data."\n");
			//$admin_logger->write('in fn members quoted fielddata = '.$this->db->quote($rule->data)."\n");
			$fieldData =$rule->data;
			//$fieldData =str_replace("'", "",$this->db->quote($rule->data)); // not necessary, the quote only add spurious quoted that I have to remove
			$admin_logger->write('in fn members new fielddata = '.str_replace("'", "",$fieldData)."\n");
		   //$fieldData = mysqli_real_escape_string($members,$rule->data); 
            switch ($rule->op) {
           case "eq":
                $fieldOperation = " = ".$fieldData."";
                break;
           case "ne":
                $fieldOperation = " != ".$fieldData."";
                break;
           case "lt":
                $fieldOperation = " < '".$fieldData."'";
                break;
           case "gt":
                $fieldOperation = " > '".$fieldData."'";
                break;
           case "le":
                $fieldOperation = " <= '".$fieldData."'";
                break;
           case "ge":
                $fieldOperation = " >= '".$fieldData."'";
                break;
           case "nu":
                $fieldOperation = " = ''";
                break;
           case "nn":
                $fieldOperation = " != ''";
                break;
           case "in":
                $fieldOperation = " IN (".$fieldData.")";
                break;
           case "ni":
                $fieldOperation = " NOT IN '".$fieldData."'";
                break;
           case "bw":
                $fieldOperation = " LIKE '".$fieldData."%'";
                break;
           case "bn":
                $fieldOperation = " NOT LIKE '".$fieldData."%'";
                break;
           case "ew":
                $fieldOperation = " LIKE '%".$fieldData."'";
                break;
           case "en":
                $fieldOperation = " NOT LIKE '%".$fieldData."'";
                break;
           case "cn":
                $fieldOperation = " LIKE '%".$fieldData."%'";
                break;
           case "nc":
                $fieldOperation = " NOT LIKE '%".$fieldData."%'";
                break;
            default:
                $fieldOperation = "";
                break;
                }
            if($fieldOperation != "") $whereArray[] = $fieldName.$fieldOperation;
        }
        if (count($whereArray)>0) {
            $where .= join(" ".$groupOperation." ", $whereArray);
        } else {
            $where = "";
        }

/*******
           foreach($rules as $rule) {
                $whereArray[] = $rule->field." like '%".$rule->data."%'";
            }
            if (count($whereArray)>0) {
                $where .= join(" and ", $whereArray);
            } else {
                $where = "";
            }


*********/ 
        }   
	$admin_logger->write('in fn members where= '.$where."\n");
	/**********************  Now get the resulting xml via SWL using this where selection ******/
	$whh =	$this->getresult_where($where);
	
	$admin_logger->write('in fn members where result = '.$whh."\n");
echo $whh;
}
else {
echo $this->getresult_where("where 1");
}  //end of else of _search
} // end of function  members


private function getresult_where( $where_to_use)
{
 $f3=$this->f3;
  $admin_logger = new Log('admin.log');
header("Content-type: text/xml;charset=utf-8");
 $page = $_GET['page']; 
 $limit = $_GET['rows']; 
 $sidx = $_GET['sidx']; 
 $sord = $_GET['sord']; 
 //$fred = $f3->get('db_user');
 $db = mysql_connect('localhost', $f3->get('db_user'),  $f3->get('db_pass')) or die("Connection Error: " . mysql_error()); 
 mysql_select_db($f3->get('db_name')) or die("Error connecting to db."); 
 // calculate the number of rows for the query. We need this for paging the result 
$result = mysql_query("SELECT COUNT(*) AS count FROM members ".$where_to_use); 
$row = mysql_fetch_array($result,MYSQL_ASSOC); 
$count = $row['count']; 
 
// calculate the total pages for the query 
if( $count > 0 && $limit > 0) { 
              $total_pages = ceil($count/$limit); 
} else { 
              $total_pages = 0; 
} 
 
// if for some reasons the requested page is greater than the total 
// set the requested page to total page 
if ($page > $total_pages) $page=$total_pages;
 
// calculate the starting position of the rows 
$start = $limit*$page - $limit;
 
// if for some reasons start position is negative set it to 0 
// typical case is that the user type 0 for the requested page 
if($start <0) $start = 0; 
 
// the actual query for the grid data 
//$SQL = "SELECT id,surname	, forename, membnum FROM members ORDER BY $sidx $sord LIMIT $start , $limit"; 
//$SQL = "SELECT id, FROM members ORDER BY $sidx $sord LIMIT $start , $limit"; 

/************Get Total paid for this selection  ************/
 $SQL_total="select sum(amtpaidthisyear)  as amt from members ".$where_to_use;
 $result = mysql_query( $SQL_total ) or die("Couldn't execute query.".mysql_error()); 
 $row = mysql_fetch_array($result,MYSQL_ASSOC); 
 $amt_total = $row['amt'];
 
 
 $SQL = "SELECT id,surname ,forename,membnum ,phone,mobile,email,membtype,location,paidthisyear,amtpaidthisyear,datejoined FROM members  ".$where_to_use." ORDER BY $sidx $sord LIMIT $start , $limit"; 
 $admin_logger->write('in getresult_where SQL = '. $SQL."\n");
 $result = mysql_query( $SQL ) or die("Couldn't execute query.".mysql_error()); 
$s = "<?xml version='1.0' encoding='utf-8'?>";
$s .=  "<rows>";
$s .= "<page>".$page."</page>";
$s .= "<total>".$total_pages."</total>";
$s .= "<records>".$count."</records>";

$s .= '<userdata name="email">Total</userdata>';   # name = target column's name
$s .= '<userdata name="amtpaidthisyear">'.$amt_total.'</userdata>'; 
   
 
// be sure to put text data in CDATA
/*
while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {
    $s .= "<row id='". $row['id']."'>";  
	
    $s .= "<cell>". $row['surname']."</cell>"; 
	$s .= "<cell>". $row['forename']."</cell>";
	$s .= "<cell>". $row['membnum']."</cell>"; 	
   // $s .= "<cell>". $row['mobile']."</cell>";
	//$s .= "<cell>". $row['phone']."</cell>";
	//$s .= "<cell>". $row['email']."</cell>";
    $s .= "</row>";
}  
*/
 while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {
   foreach($row as $key => $value)
      {if ($key=='id') {$s .= "<row id='". $value."'>";  }
	  else
	  { $s .= "<cell>". "$value"."</cell>";
	  
	  }
         //$key holds the table column name
       
   
   }
$s .= "</row>"; 
	
	} 
$s .= "</rows>"; 

$admin_logger->write('in getresult_where result = '.$s."\n");
	return $s;

	
}
public function users()
	 {
	 $f3=$this->f3;
	 
	 $f3->set('page_head','User List');

header("Content-type: text/xml;charset=utf-8");
 $page = $_GET['page']; 
 $limit = $_GET['rows']; 
 $sidx = $_GET['sidx']; 
 $sord = $_GET['sord']; 
 //$fred = $f3->get('db_user');
 $db = mysql_connect('localhost', $f3->get('db_user'),  $f3->get('db_pass')) or die("Connection Error: " . mysql_error()); 
 mysql_select_db($f3->get('db_name')) or die("Error connecting to db."); 
 // calculate the number of rows for the query. We need this for paging the result 
$result = mysql_query("SELECT COUNT(*) AS count FROM mem_users"); 
$row = mysql_fetch_array($result,MYSQL_ASSOC); 
$count = $row['count']; 
 
// calculate the total pages for the query 
if( $count > 0 && $limit > 0) { 
              $total_pages = ceil($count/$limit); 
} else { 
              $total_pages = 0; 
} 
 
// if for some reasons the requested page is greater than the total 
// set the requested page to total page 
if ($page > $total_pages) $page=$total_pages;
 
// calculate the starting position of the rows 
$start = $limit*$page - $limit;
 
// if for some reasons start position is negative set it to 0 
// typical case is that the user type 0 for the requested page 
if($start <0) $start = 0; 
 
// the actual query for the grid data 
//$SQL = "SELECT id,surname	, forename, membnum FROM members ORDER BY $sidx $sord LIMIT $start , $limit"; 
//$SQL = "SELECT id, FROM members ORDER BY $sidx $sord LIMIT $start , $limit"; 
 $SQL = "SELECT id,username ,email,role FROM mem_users ORDER BY $sidx $sord LIMIT $start , $limit"; 
$result = mysql_query( $SQL ) or die("Couldn't execute query.".mysql_error()); 
$s = "<?xml version='1.0' encoding='utf-8'?>";
$s .=  "<rows>";
$s .= "<page>".$page."</page>";
$s .= "<total>".$total_pages."</total>";
$s .= "<records>".$count."</records>";

//$s .= '<userdata name="email">Total</userdata>';   # name = target column's name
//$s .= '<userdata name="amtpaidthisyear">1b2b3b</userdata>';
   
 
// be sure to put text data in CDATA

 while($row = mysql_fetch_array($result,MYSQL_ASSOC)) {
   foreach($row as $key => $value)
      {if ($key=='id') {$s .= "<row id='". $value."'>";  }
	  else
	  { $s .= "<cell>". "$value"."</cell>";
	  
	  }
         //$key holds the table column name
       
   
   }
$s .= "</row>"; 
	
	} 
$s .= "</rows>"; 
	echo $s;
} // end of function  users
public function edituser()
	 {
	 $f3=$this->f3; 
	 	$admin_logger = new Log('admin.log');
	$admin_logger->write('in edituser');
	// $memuser = new DB\SQL\Mapper($this->db, 'mem_users',array("id","username","email","role")); 
	// $f3->get('POST.oper');

	  //$this->f3->set('mem_users',$user->all());
	// echo (' POST.oper = '.$f3->get('POST.oper'));
	$mem_user =	new User($this->db);
 $f3->set('mem_user',$mem_user);
	 switch ($f3->get('POST.oper')) {
    case "add":
        // do mysql insert statement here
		$mem_user->copyfrom('POST');
		$salt=$f3->get('security_salt'); 
		$encrypt_pwd =crypt($mem_user->password, '$2y$12$' . $salt); //generate the password
		
		$admin_logger->write('in edituser uname '.$mem_user->username);
		$admin_logger->write('in edituser pwd '.$mem_user->password);
		$mem_user->password = $encrypt_pwd ;
		$admin_logger->write('in edituser pwd '.$mem_user->password);
		$admin_logger->write('in edituser pwd'.$mem_user->password."##\n");
		$mem_user->save();
    break;
    case "edit":
		  
		  
		 // $f3->get('mem_user')->load(array('id =:id',array(':id'=> $f3->get('POST.id')) ) );
		  $mem_user->load(array('id =:id',array(':id'=> $f3->get('POST.id')) ) );
	$admin_logger->write('in edituser '.$f3->get('mem_user')->username);
	  $mem_user->copyfrom('POST');
	
	  $mem_user->update();
        // do mysql update statement here
	//	/
    break;
    case "del":
        // do mysql delete statement here
    break;
}
	// echo $f3->get('POST.oper');
	}

public function editmember()
	 {
	 $f3=$this->f3; 
	 	$admin_logger = new Log('admin.log');
	$admin_logger->write('in editmember');

	$members =	new Member($this->db);
 $f3->set('members',$members);
	 switch ($f3->get('POST.oper')) {
    case "add":
        // do mysql insert statement here
		
		/******  Find the next membership number as the highest+1**/
	
	
	//$result=$this->db->exec('SELECT max(membnum) as maxnum FROM members '); 
	$result=$this->db->exec('SELECT membnum FROM members order by membnum DESC LIMIT 1'); 
	$admin_logger->write('in addmember MAXMEMBNUM= = '.print_r($result));
	var_dump("Line 390");
	var_dump($result);
	$admin_logger->write('in addmember db log = '.$this->db->log()."\n");

//foreach($result as $row)
//$admin_logger->write('each row of result = '.$row['membnum']."\n");

	$admin_logger->write('in addmember maxmembnum row = '.$result[0]['membnum']."\n");

	$max_membnum = ((int) $result[0]['membnum'])+1;
//exit("EXIT LEY4\n");
	
		$members->copyfrom('POST');
		$admin_logger->write('in addmember maxmembnum = '.$members->membnum."\n");
		$members->membnum=$max_membnum;
		
		
		$admin_logger->write('in addmember paidthisyear = '.$members->paidthisyear);
		if ($members->paidthisyear=="Y")	{ 
		$thismember= $members->membnum;
		/***  calculate the amount paid  if added as zero ******/
		if ($members->amtpaidthisyear> 0) {$admin_logger->write('in addmember amountpaid = '.$members->amtpaidthisyear);
			}	
		
		else {
		$admin_logger->write('in addmember NO amount paidthisyear ');
		$feespertypes = new \DB\SQL\Mapper($this->db, 'feespertypes');
		$feespertypes->load(array('membtype =:membtype',array(':membtype'=> $f3->get('POST.membtype')) ) );
		$feetopay = $feespertypes->feetopay;
		$members->amtpaidthisyear = $feetopay;
		}}
		$admin_logger->write('in addmember uname '.$members->surname);
		$admin_logger->write('in addmember Forename '.$members->forename);
		
			

		$members->save();
    break;
    case "edit":
		  
		  
		 // $f3->get('members')->load(array('id =:id',array(':id'=> $f3->get('POST.id')) ) );
		  $members->load(array('id =:id',array(':id'=> $f3->get('POST.id')) ) );
	$admin_logger->write('in editmember for '.$members->surname.' membnum '.$members->membnum.' paidthis year '.$members->paidthisyear);
	
	/*********IF the field paidthisyear has been changed from N to Y then also update the amtpaidthisyear using feespertypes table *****/
	$wasnotpaid=false;
	if ($members->paidthisyear=="N")	{$wasnotpaid=true;}
	/**** now fetch the existing row to check if paidthisyear is about to change ****/
	$admin_logger->write('in editmember for wasnotpaid = '.$wasnotpaid);
		
		//$thismember= $members->membnum;
		$members->copyfrom('POST');
	// ********* calculate amount paid
	//$feespertpes =	new Feespertypes($this->db);
	$feespertypes = new \DB\SQL\Mapper($this->db, 'feespertypes');
	$feespertypes->load(array('membtype =:membtype',array(':membtype'=> $f3->get('POST.membtype')) ) );
	$admin_logger->write('in editmember /feespertype '.$feespertypes->membtype.' feetopay '.$feespertypes->feetopay);
	$feetopay = $feespertypes->feetopay;
	var_dump($members);
	
	if($wasnotpaid && ($members->paidthisyear=="Y")) { $members->amtpaidthisyear= $feespertypes->feetopay;}
	if(!$wasnotpaid && ($members->paidthisyear=="N")) { $members->amtpaidthisyear= 0;}
	
	var_dump($members);
	
		$members->update();
        // do mysql update statement here
	//	/
    break;
    case "del":
        // do mysql delete statement here
		$members->load(array('id =:id',array(':id'=> $f3->get('POST.id')) ) );
		$members->erase();
    break;
}
	// echo $f3->get('POST.oper');
	}
	
	function markpaid() { 
	 $f3=$this->f3; 
	$admin_logger = new Log('admin.log');
	$admin_logger->write('in markpaid '.$this->f3->get('POST.membnum') );
	$members =	new Member($this->db);
	$members->load(array('membnum =:id',array(':id'=> $f3->get('POST.membnum')) ));
	$members->paidthisyear='Y';
	$thismember= $members->membnum;
	$members->update();
	echo('Done that');	}
	
} // end of class